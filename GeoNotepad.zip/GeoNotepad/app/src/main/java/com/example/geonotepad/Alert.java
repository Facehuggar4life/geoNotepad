package com.example.geonotepad;

import android.content.Intent;
import android.content.IntentSender;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Alert extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getIntent().getExtras();
        boolean isLocationAlert = bundle.getBoolean("isLocationAlert");
        System.out.println(isLocationAlert);
        if(isLocationAlert){
            setContentView(R.layout.location_alert);
        }
        else{
            setContentView(R.layout.activity_alert);
            TextView text = findViewById(R.id.error_textbox);
            text.setText(bundle.getString("textContent"));
        }
    }

    public void revertActivity(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void launchLocationpreferences(View view){
        Intent settingsIntent = new Intent(android.provider.Settings.ACTION_SETTINGS);
        startActivity(settingsIntent);
    }
}