package com.example.geonotepad;

public class Coordinate {
    String Longitude;
    String Latitude;
    public Coordinate (String Long, String Lat){
        Longitude = Long;
        Latitude = Lat;
    }
}