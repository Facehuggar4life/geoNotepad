package com.example.geonotepad;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.IOException;

public class GeoOpener extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_geo_opener);
    }

    public void getString(View view) {
        //Text field's content is retrieved and used to find location data
        TextView textView = findViewById(R.id.notepad_text_field);
        String enteredText = textView.getText().toString();
        openGoogleMaps(enteredText);
    }

    public void openGoogleMaps(String enteredName) {
        DataManipulator dataManipulator = new DataManipulator();
        Coordinate locationData = null;
        try {
            locationData = dataManipulator.readLocationData(getBaseContext(), enteredName);
            //Makes an instance of the storage class "Coordinate" from dataManipulator's output
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(locationData);
        if (locationData == null) {
            //Launches error if no location data exists
            Intent errorIntent = new Intent(this, Alert.class);
            Bundle stringBundle = new Bundle();
            stringBundle.putString("textContent", "Data could not be found");
            stringBundle.putBoolean("isLocationAlert", false);
            errorIntent.putExtras(stringBundle);
            startActivity(errorIntent);
        }
        else{
            //Opens google maps with data from the coordinate class
            Uri mapsUri = Uri.parse("geo:" + locationData.Longitude + ", " + locationData.Latitude);
            Intent intent = new Intent(Intent.ACTION_VIEW, mapsUri);
            intent.setPackage("com.google.android.apps.maps");
            startActivity(intent);
        }
    }
}