package com.example.geonotepad;

import android.content.Context;
import android.location.Location;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class DataManipulator {
    final String fileName = "location_data.txt";

    public void writeLocationData(Context context, String locationName, Location pictureLocation) throws IOException {
        File locationFile = new File(context.getFilesDir(), fileName);
        BufferedWriter writer = new BufferedWriter(new FileWriter(locationFile, true));
        writer.write(locationName+'\n');
        writer.write(pictureLocation.getLongitude()+":"+pictureLocation.getLatitude()+'\n');
        //Writes the name of the photo file and the Longitude and Latitude separated by a colon
        writer.close();
    }

    public Coordinate readLocationData(Context context, String locationName) throws IOException {
        File locationFile = new File(context.getFilesDir(), fileName);
        BufferedReader reader = new BufferedReader(new FileReader(locationFile));
        String currentLine = reader.readLine();
        System.out.println(currentLine);
        System.out.println("Started");
        System.out.println("locationName "+ locationName);
        while (currentLine != null) {
            if (currentLine.equals(locationName)) {
                System.out.println("positive");
                currentLine = reader.readLine();
                System.out.println(currentLine);
                Coordinate parsedCoordinate = parseCoordinates(currentLine);
                System.out.println(parsedCoordinate.Longitude);
                System.out.println(parsedCoordinate.Latitude);
                return parsedCoordinate;
            } else {
                currentLine = reader.readLine();
            }
            System.out.println(currentLine+" loop");
        }
        reader.close();
        return null;
    }
    public Coordinate parseCoordinates(String stringCoordinates){
        String Long = stringCoordinates.substring(0, (stringCoordinates.indexOf(':'))-1);
        String Lat = stringCoordinates.substring(stringCoordinates.indexOf(':')+1, stringCoordinates.length()-1);
        int longPointIndex = Long.indexOf('.');
        int latPointIndex = Lat.indexOf('.');
        Long = Long.substring(0, longPointIndex+5);
        Lat = Lat.substring(0, latPointIndex+5);
        Coordinate coordinate = new Coordinate(Long, Lat);
        return coordinate;
    }
    public String chomp(String string){
        System.out.println(string+" chomp");
        Integer newlineIndex = string.indexOf('\n');
        System.out.println(newlineIndex);
        if(newlineIndex>-1){
            string = string.substring(0, newlineIndex-1);
        }
       return string;
    }
}
